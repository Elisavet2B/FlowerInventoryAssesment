﻿using Microsoft.AspNetCore.Components;
using FlowerInventory.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;
using FlowerInventory.Repositories.Interfaces;

namespace FlowerInventory.Pages
{
    public partial class FlowerDetailsPage
    {
        [Parameter] public int flowerId { get; set; }  // Capture flowerId from the URL

        private Flower flower;

        // This method will get the flower by ID when the page is initialized.
        protected override async Task OnInitializedAsync()
        {
            try
            {
                flower = await FlowerRepository.GetFlowerById(flowerId);

                if (flower == null)
                {
                    // If the flower is not found, navigate back to the list
                    Navigation.NavigateTo("/");
                }
            }
            catch (Exception ex)
            {
                // Handle any potential errors (e.g., network issues)
                Console.WriteLine($"Error fetching flower: {ex.Message}");
                Navigation.NavigateTo("/");
            }
        }

        // Navigate back to the flower list page
        private void GoBack()
        {
            Navigation.NavigateTo("/");
        }
    }
}