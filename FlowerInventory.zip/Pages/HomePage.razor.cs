﻿using Microsoft.AspNetCore.Components;
using FlowerInventory.Entities;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FlowerInventory.Repositories.Interfaces;

namespace FlowerInventory.Pages
{
    public partial class HomePage
    {
        private List<Flower> flowers = new List<Flower>();
        private List<Category> categories = new List<Category>();
        private List<Flower> filteredFlowers = new List<Flower>(); 
        private string searchQuery = "";
        private string selectedCategory = "";
        private string priceSortOrder = ""; 

        private bool showDeleteConfirmation = false;
        private int flowerToDeleteId;

        protected override async Task OnInitializedAsync()
        {
            await LoadFlowers();
            await LoadCategories();
        }

        private async Task LoadFlowers()
        {
            flowers = await FlowerRepository.GetAllFlowers();
            ApplyFilters();
        }

        private async Task LoadCategories()
        {
            categories = await CategoryRepository.GetAllCategories();
        }

        private void ApplyFilters()
        {
            var filtered = flowers.AsEnumerable();

            
            if (!string.IsNullOrEmpty(searchQuery))
            {
                filtered = filtered.Where(f => f.FlowerName.Contains(searchQuery, System.StringComparison.OrdinalIgnoreCase));
            }

            
            if (!string.IsNullOrEmpty(selectedCategory))
            {
                filtered = filtered.Where(f => f.Category.CategoryName.Equals(selectedCategory, System.StringComparison.OrdinalIgnoreCase));
            }

  
            if (priceSortOrder == "asc")
            {
                filtered = filtered.OrderBy(f => f.FlowerPrice);
            }
            else if (priceSortOrder == "desc")
            {
                filtered = filtered.OrderByDescending(f => f.FlowerPrice);
            }

            filteredFlowers = filtered.ToList();
        }
        private void OnSearchChanged(ChangeEventArgs e)
        {
            searchQuery = e.Value.ToString();
            ApplyFilters();
        }
        private void OnCategoryChanged(ChangeEventArgs e)
        {
            selectedCategory = e.Value.ToString();
            ApplyFilters();
        }

        private void OnPriceSortChanged(ChangeEventArgs e)
        {
            priceSortOrder = e.Value.ToString();
            ApplyFilters();
        }

        private void ConfirmDelete(int flowerId)
        {
            flowerToDeleteId = flowerId;
            showDeleteConfirmation = true;
        }

        private async Task DeleteConfirmed()
        {
            await FlowerRepository.DeleteFlower(flowerToDeleteId);
            showDeleteConfirmation = false;
            await LoadFlowers();
        }

        private void CancelDelete()
        {
            showDeleteConfirmation = false;
        }

        private void GoToAddFlowerPage()
        {
            NavigationManager.NavigateTo("/add-flower");
        }

        private void EditFlower(int flowerId)
        {
            NavigationManager.NavigateTo($"/edit-flower/{flowerId}");
        }

        private void ViewDetails(int flowerId)
        {
            NavigationManager.NavigateTo($"/flower-details/{flowerId}");
        }
    }
}
