﻿using Microsoft.AspNetCore.Components;
using FlowerInventory.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;
using FlowerInventory.Repositories.Interfaces;
using FlowerInventory.Repositories;

namespace FlowerInventory.Pages
{
    public partial class CategoriesPage
    {
        private List<Category> categories;

        protected override async Task OnInitializedAsync()
        {
            // Fetch categories directly from the repository
            categories = await CategoryRepository.GetAllCategories();
        }
    }
}