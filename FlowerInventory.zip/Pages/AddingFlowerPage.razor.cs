﻿using Microsoft.AspNetCore.Components;
using FlowerInventory.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;
using FlowerInventory.Repositories.Interfaces;

namespace FlowerInventory.Pages
{
    public partial class AddingFlowerPage
    {
        private Flower newFlower = new Flower();
        private List<Category> Categories = new();

        protected override async Task OnInitializedAsync()
        {
            Categories = await CategoryRepository.GetAllCategories(); 
        }

        private async Task AddFlower()
        {
            if (newFlower.FlowerName != null && newFlower.FlowerType != null && newFlower.FlowerPrice > 0)
            {
                await FlowerRepository.AddFlower(newFlower);
                newFlower = new Flower(); 
            }
        }
        private void GoBack()
        {
            Navigation.NavigateTo("/");
        }
    }
}