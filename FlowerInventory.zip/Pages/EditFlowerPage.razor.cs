﻿using Microsoft.AspNetCore.Components;
using FlowerInventory.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;
using FlowerInventory.Repositories.Interfaces;
using FlowerInventory.Repositories;

namespace FlowerInventory.Pages
{
    public partial class EditFlowerPage
    {
        [Parameter] public int FlowerId { get; set; }

        private Flower flower = new Flower();
        private List<Category> categories = new List<Category>();

        // Load flower data and categories when page loads
        protected override async Task OnInitializedAsync()
        {
            // Fetch the flower to edit
            flower = await FlowerRepository.GetFlowerById(FlowerId);

            // Fetch the available categories for dropdown
            categories = await CategoryRepository.GetAllCategories();
        }

        // Handle saving the changes
        private async Task SaveFlower()
        {
            if (flower != null)
            {
                await FlowerRepository.UpdateFlower(flower);
                NavigationManager.NavigateTo("/"); // Redirect to home page
            }
        }

        // Handle going back without saving changes
        private void GoBack()
        {
            NavigationManager.NavigateTo("/"); // Redirect to home page
        }
    }
}