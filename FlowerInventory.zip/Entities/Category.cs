﻿namespace FlowerInventory.Entities
{
    public class Category
    {
        public int CategoryID { get; set; }
        public string? CategoryName { get; set; }
        public ICollection<Flower> Flowers { get; set; } = new List<Flower>();
    }
}
