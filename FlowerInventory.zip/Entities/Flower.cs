﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FlowerInventory.Entities
{
    public class Flower
    {
        public int FlowerID { get; set; }

        [Required(ErrorMessage = "Flower Name is required.")]
        public string? FlowerName { get; set; }

        [Required(ErrorMessage = "Flower Type is required.")]
        public string? FlowerType { get; set; }

        [Range(0.01, double.MaxValue, ErrorMessage = "Flower Price must be greater than 0.")]
        public decimal FlowerPrice { get; set; }

        [Required(ErrorMessage = "Category is required.")]
        [ForeignKey ("CategoryID")]
        public virtual Category Category { get; set; }
        public int? CategoryID { get; set; }
       
    }
}
