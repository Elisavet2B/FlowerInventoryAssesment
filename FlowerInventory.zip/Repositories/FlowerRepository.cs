﻿using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using FlowerInventory.Entities;
using FlowerInventory.Repositories.Interfaces;
using FlowerInventoryApp.Server.Data;

namespace FlowerInventory.Repositories
{
    public class FlowerRepository : IFlowerRepository
    {
        private readonly FlowerInventoryDbContext _context;

        public FlowerRepository(FlowerInventoryDbContext flowerInventoryDbContext)
        {
            _context = flowerInventoryDbContext;
        }
        public async Task<List<Flower>> GetAllFlowers()
        {
            return await _context.Flowers.Include(f => f.Category).ToListAsync();
        }

        // Get a flower by its ID
        public async Task<Flower> GetFlowerById(int id)
        {
            return await _context.Flowers
                .Include(f => f.Category)
                .FirstOrDefaultAsync(f => f.FlowerID == id);
        }

        public async Task AddFlower(Flower flower)
        {
            await _context.Flowers.AddAsync(flower);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateFlower(Flower flower)
        {
            _context.Flowers.Update(flower);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteFlower(int id)
        {
            var flower = await _context.Flowers.FindAsync(id);
            if (flower != null)
            {
                _context.Flowers.Remove(flower);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<List<Flower>> GetFlowersSorted(int pageNumber, int pageSize, string sortBy, bool ascending = true)
        {
            IQueryable<Flower> query = _context.Flowers.Include(f => f.Category);

            switch (sortBy.ToLower())
            {
                case "name":
                    query = ascending ? query.OrderBy(f => f.FlowerName) : query.OrderByDescending(f => f.FlowerName);
                    break;
                case "price":
                    query = ascending ? query.OrderBy(f => f.FlowerPrice) : query.OrderByDescending(f => f.FlowerPrice);
                    break;
                case "type":
                    query = ascending ? query.OrderBy(f => f.FlowerType) : query.OrderByDescending(f => f.FlowerType);
                    break;
                default:
                    // Default sorting by name if no valid sortBy is provided
                    query = ascending ? query.OrderBy(f => f.FlowerName) : query.OrderByDescending(f => f.FlowerName);
                    break;
            }

            return await query
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();
        }

    }
}
