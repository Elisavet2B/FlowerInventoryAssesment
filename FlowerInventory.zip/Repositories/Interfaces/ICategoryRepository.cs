﻿using System.Threading.Tasks;
using System.Collections.Generic;
using FlowerInventory.Entities;

namespace FlowerInventory.Repositories.Interfaces
{
    public interface ICategoryRepository
    {
        Task<List<Category>> GetAllCategories();
        Task<Category> CreateCategory(Category newCategory); 
        Task<bool> DeleteCategory(long categoryId);  
        Task<Category> UpdateCategory(long categoryId, Category categoryToUpdate);  
    }
}
