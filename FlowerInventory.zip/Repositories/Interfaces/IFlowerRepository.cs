﻿using System.Threading.Tasks;
using System.Collections.Generic;
using FlowerInventory.Entities;

namespace FlowerInventory.Repositories.Interfaces
{
    public interface IFlowerRepository
    {
        Task<List<Flower>> GetAllFlowers();                  
        Task<Flower> GetFlowerById(int id);                  
        Task AddFlower(Flower flower);                        
        Task UpdateFlower(Flower flower);                    
        Task DeleteFlower(int id);                        
        Task<List<Flower>> GetFlowersSorted(int pageNumber, int pageSize, string sortBy, bool ascending = true); 
    }
}
