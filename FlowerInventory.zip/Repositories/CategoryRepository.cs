﻿using FlowerInventory.Entities;
using FlowerInventory.Repositories.Interfaces;
using FlowerInventoryApp.Server.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlowerInventory.Repositories
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly FlowerInventoryDbContext _context;

        public CategoryRepository(FlowerInventoryDbContext flowerInventoryDbContext)
        {
            _context = flowerInventoryDbContext;
        }

      
        public async Task<List<Category>> GetAllCategories()
        {
            return await _context.Categories
                .Include(c => c.Flowers)  
                .ToListAsync();
        }

        public async Task<Category> CreateCategory(Category newCategory)
        {
            _context.Categories.Add(newCategory);
            await _context.SaveChangesAsync();
            return newCategory;
        }

        public async Task<bool> DeleteCategory(long categoryId)
        {
            var category = await _context.Categories.FindAsync(categoryId);
            if (category != null)
            {
                _context.Categories.Remove(category);
                await _context.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public async Task<Category> UpdateCategory(long categoryId, Category categoryToUpdate)
        {
            var existingCategory = await _context.Categories.FindAsync(categoryId);
            if (existingCategory != null)
            {
                existingCategory.CategoryName = categoryToUpdate.CategoryName;

                await _context.SaveChangesAsync();
                return existingCategory;
            }
            return null;
        }
       

    }
}
