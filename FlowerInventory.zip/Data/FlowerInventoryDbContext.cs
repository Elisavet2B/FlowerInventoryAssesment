﻿using Microsoft.EntityFrameworkCore;
using FlowerInventory.Entities;

namespace FlowerInventoryApp.Server.Data
{
    public class FlowerInventoryDbContext : DbContext
    {
        public FlowerInventoryDbContext(DbContextOptions<FlowerInventoryDbContext> options)
            : base(options)
        {
        }

        public DbSet<Flower> Flowers { get; set; }
        public DbSet<Category> Categories { get; set; }

       
    }
}

